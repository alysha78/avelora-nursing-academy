# AVELORA – Nursing Academy
Wissen. Pflege. Kompetenz.

Lern-App für die generalistische Pflegeausbildung (Lernmodule, Quiz, Karteikarten, Rechentrainer, Wochenplan, Fortschritt, Profil).

## Online stellen mit GitHub Pages
1. Auf github.com ein neues Repository anlegen (z. B. `avelora-nursing-academy`, öffentlich).
2. „Add file" → „Upload files": alle Dateien dieses Ordners hochladen (index.html, manifest.webmanifest, sw.js, icon.svg, README.md) → „Commit changes".
3. Settings → Pages → Source: „Deploy from a branch", Branch `main`, Ordner `/ (root)` → Save.
4. Nach 1–2 Minuten ist die Seite erreichbar unter `https://DEIN-NAME.github.io/avelora-nursing-academy/`.

## Als App auf dem iPhone
Link in Safari öffnen → Teilen → „Zum Home-Bildschirm".

## Hinweise
- Fortschritt, Profil und Quizergebnisse werden lokal im Browser gespeichert.
- Der KI-Assistent funktioniert nur innerhalb von Claude. Auf GitHub Pages braucht er einen eigenen Server (Backend) mit API-Schlüssel.
- Lerninhalte mit Unterricht und Hausstandards abgleichen. Keine Dosierungsempfehlungen für reale Patienten.
